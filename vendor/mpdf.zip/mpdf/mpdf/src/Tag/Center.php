<?php

namespace Mpdf\Tag;

class Center extends BlockTag
{


}
