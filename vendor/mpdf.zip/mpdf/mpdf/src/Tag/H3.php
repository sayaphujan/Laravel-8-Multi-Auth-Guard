<?php

namespace Mpdf\Tag;

class H3 extends BlockTag
{


}
